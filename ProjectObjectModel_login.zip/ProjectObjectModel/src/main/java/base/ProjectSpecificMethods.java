package base;

import java.io.File;
import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utilits.ReadExcel;

public class ProjectSpecificMethods {

	public ChromeDriver driver;
	public static Properties prop;
	public String fileName;
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	public  ExtentTest test;
	public String testName,testDescription,testAuthor,testCategory,testData;
	public ExtentTest eachNode;

	
	  @BeforeSuite public void loadproperties() throws FileNotFoundException,
	  IOException { 
		  prop=new Properties();
	  
	  prop.load(new FileInputStream("./src/main/resources/english.properties"));
	  }
	 
	@BeforeSuite
	public void startReport()
	{
		reporter= new  ExtentHtmlReporter("./extentReport/result.html");
		extent= new ExtentReports();
		extent.attachReporter(reporter);
		reporter.setAppendExisting(true);
		
	}
	@BeforeClass
	public void testDetails()
	{
		test = extent.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	@AfterSuite
	public void stopReport()
	{
		extent.flush();
	}
	public void reportStep(String msg,String status) throws IOException
	{
		if(status.equalsIgnoreCase("Pass"))
		{
			eachNode.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
		else
		{
			eachNode.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
	}
	public long takeSnap() throws IOException {
		// TODO Auto-generated method stub
		long number= (long)(Math.floor(Math.random()*900000000L)+10000000L);
		File src=driver.getScreenshotAs(OutputType.FILE);
		File des= new File("./snaps/img"+number+".png");
		FileUtils.copyFile(src,des);
		return number;
		
	}
	@BeforeMethod
	public void startApp()
	{
		eachNode=test.createNode(testName);
	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
    driver = new ChromeDriver();	 
	driver.manage().window().maximize();
	driver.get("http://leaftaps.com/opentaps/control/main");
	}
	
	@AfterMethod
	public void closeBrowser()
	{
		driver.close();
	}
	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException {

		return ReadExcel.readData(fileName);

	}


}
