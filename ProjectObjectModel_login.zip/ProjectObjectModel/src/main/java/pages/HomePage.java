package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	HomePage(ChromeDriver driver,ExtentTest eachNode, ExtentTest test)
	
	{
		this.driver=driver;
		this.eachNode=eachNode;
		this.test=test;
	}
	
	//click logout button
	public LoginPage clickLogoutButton() throws IOException
	{
		try {
			driver.findElementByClassName(prop.getProperty("Homepage.logout.class")).click();
			reportStep("logged out succesfully", "Pass");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			reportStep("not logged out succesfully", "fail");
		}
		return new LoginPage(driver,eachNode, test);
	}
	//click crmsfalink
	public MyHomePage clickCrmsaLink() {
		driver.findElementByLinkText("CRM/SFA").click();	
		return new MyHomePage();
	
	}
	//verification homepage
	public HomePage verifyHomepage()
	{
		System.out.println("homepage verified");
		//Assert.assertTrue(false, "driver.findElementByLinkText(\"CRM/SFA\")").isDisplayed();
		return this;
	}
	
	}


