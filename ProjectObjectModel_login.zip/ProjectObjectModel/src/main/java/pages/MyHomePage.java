package pages;

public class MyHomePage {

}
