package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	public LoginPage(ChromeDriver driver,ExtentTest test,ExtentTest eachNode)
	{
	this.driver=driver;	
	this.eachNode=eachNode;
	this.test=test;
	//PageFactory.initElements(driver, this);
	}	
	
	//@FindBy(how= How.ID,using="username")
	//WebElement uName;
	//enter username
	
	public LoginPage enterUsername(String username) throws IOException {
		//uName.sendKeys(data);
		try {
			driver.findElementById(prop.getProperty("login.username.id")).sendKeys(username);
			reportStep("username entered:success","pass");
		} catch (Exception e) {
			
			reportStep("username not entered:success","fail");
		}
		return this;
	}

	/*
	 * @FindBy(how=How.ID,using="password") WebElement password;
	 */
	//enter password
	public LoginPage enterPassword(String data) throws IOException
	{
		//password.sendKeys(data);
		try {
			driver.findElementById(prop.getProperty("login.password.id")).sendKeys(data);
			reportStep("password entered:success","pass");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			reportStep("password not entered:success","fail");
		}
		return this;
	}

	/*
	 * @FindBy(how=How.CLASS_NAME,using="decorativeSubmit") WebElement loginbutton;
	 */
	//click login button
	public HomePage clickLoginButton () throws IOException
	{
		//loginbutton.click();
		try {
			driver.findElementByClassName(prop.getProperty("login.login.class")).click();
			reportStep("Clicked login button successfully", "pass");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			reportStep("Clicked not login button successfully", "fail");
		}
		return new HomePage(driver,test,eachNode);
	//	Thread.sleep(2000);
	}
	
}
