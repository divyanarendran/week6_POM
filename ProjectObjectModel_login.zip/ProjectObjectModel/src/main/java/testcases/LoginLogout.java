package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginLogout extends ProjectSpecificMethods
{
	@BeforeTest
	public void setData() {
		fileName = "Login";
		testName="LoginLogout";
		testData="Test login for positive values";
		testAuthor="divya";
		testCategory="functional";

}
	@Test(dataProvider="fetchData")
	public void loginlogout(String username, String password) throws IOException
	{
		new LoginPage(driver,test,eachNode).enterUsername(username)
		
		.enterPassword(password)
		.clickLoginButton().clickLogoutButton();
		//.clickCrmsaLink();
		
		
	}

}