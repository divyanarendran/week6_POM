
package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class Login extends ProjectSpecificMethods{
	@BeforeTest
	public void setData() {
		fileName = "Login";
		testName="Login";
		testData="Test login positive values";
		testAuthor="divya";
		testCategory="functional1";

}
	@Test(dataProvider="fetchData")
	
	
	public void login(String Username, String password) throws IOException
	{
		new LoginPage(driver,test,eachNode).enterUsername(Username)
		
		.enterPassword(password).clickLoginButton();
		//.clickLoginButton();
		//.clickCrmsaLink();

}
}
